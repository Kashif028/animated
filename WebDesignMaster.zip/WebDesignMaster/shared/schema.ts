import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  prompt: text("prompt").notNull(),
  duration: integer("duration").notNull(), // in seconds
  style: text("style").notNull(),
  quality: text("quality").notNull(),
  voiceType: text("voice_type"), // 'male', 'female', 'child', 'robotic'
  musicStyle: text("music_style"), // 'cinematic', 'upbeat', 'ambient', 'none'
  includeVoiceover: boolean("include_voiceover").default(false),
  status: text("status").notNull(), // 'generating', 'completed', 'failed'
  progress: integer("progress").default(0), // 0-100
  thumbnailUrl: text("thumbnail_url"),
  videoUrl: text("video_url"),
  audioUrl: text("audio_url"),
  fileSize: text("file_size"),
  userId: integer("user_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertVideoSchema = createInsertSchema(videos).pick({
  prompt: true,
  duration: true,
  style: true,
  quality: true,
  voiceType: true,
  musicStyle: true,
  includeVoiceover: true,
});

export const updateVideoSchema = createInsertSchema(videos).pick({
  status: true,
  progress: true,
  thumbnailUrl: true,
  videoUrl: true,
  audioUrl: true,
  fileSize: true,
}).partial();

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type UpdateVideo = z.infer<typeof updateVideoSchema>;
export type Video = typeof videos.$inferSelect;
