# AI Video Generator API

A Python Flask API that creates AI-powered videos using:
- **Stable Diffusion** for image generation
- **Google Text-to-Speech** for voiceover
- **FFmpeg** for video creation

## Quick Start

1. **Run the API:**
```bash
python ai_api.py
```

2. **Open your browser:**
```
http://localhost:8000
```

## API Endpoints

### POST /api/generate-image
Generate images using Stable Diffusion
```javascript
fetch('http://localhost:8000/api/generate-image', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        prompt: "A cute cartoon rabbit in a meadow",
        style: "cinematic",
        width: 1024,
        height: 1024
    })
})
```

### POST /api/generate-voice
Create voiceover with Google TTS
```javascript
fetch('http://localhost:8000/api/generate-voice', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        text: "Welcome to AI Video Generator",
        voice_type: "female",
        language_code: "en-US"
    })
})
```

### POST /api/generate-video
Generate complete video with FFmpeg
```javascript
fetch('http://localhost:8000/api/generate-video', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        prompt: "Animated cartoon animals dancing",
        duration: 10,
        style: "cartoon",
        quality: "1080p",
        voice_type: "child",
        music_style: "upbeat",
        include_voiceover: true
    })
})
```

### GET /api/health
Check API status
```javascript
fetch('http://localhost:8000/api/health')
```

## Configuration

### Environment Variables

```bash
# Stability AI API Key (required for image generation)
export STABILITY_API_KEY="your_stability_api_key"

# Google Cloud credentials (required for TTS)
export GOOGLE_APPLICATION_CREDENTIALS="path/to/credentials.json"
```

### Getting API Keys

1. **Stability AI:** Get your API key from [platform.stability.ai](https://platform.stability.ai)
2. **Google TTS:** Set up credentials at [Google Cloud Console](https://cloud.google.com/text-to-speech)

## Features

- Real-time video generation progress tracking
- Multiple voice types (male, female, child, robotic)
- Various art styles (cinematic, realistic, artistic, cartoon)
- Automatic image-to-video conversion
- Audio synchronization
- Cross-origin resource sharing (CORS) enabled

## Video Generation Process

1. **Image Generation:** Creates multiple frames using Stable Diffusion
2. **Voice Synthesis:** Generates voiceover using Google TTS
3. **Video Assembly:** Combines images and audio using FFmpeg
4. **Output:** Returns final MP4 video with synchronized audio

## Error Handling

The API provides detailed error messages for:
- Missing API keys
- Invalid prompts
- Service unavailability
- FFmpeg processing errors

## File Structure

```
├── ai_api.py          # Main Flask API
├── script.js          # Frontend JavaScript client
├── index.html         # Web interface
├── static/            # Generated files (images, audio, videos)
└── README.md          # Documentation
```