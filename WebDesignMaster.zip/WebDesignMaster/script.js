// AI Video Generator API Client
class AIVideoAPI {
    constructor(baseURL = 'http://localhost:8000') {
        this.baseURL = baseURL;
    }

    // Helper method for making fetch requests
    async makeRequest(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
            },
            ...options
        };

        try {
            const response = await fetch(url, defaultOptions);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || `HTTP error! status: ${response.status}`);
            }
            
            return data;
        } catch (error) {
            console.error('API Request failed:', error);
            throw error;
        }
    }

    // Generate image using Stable Diffusion
    async generateImage(prompt, style = 'realistic', width = 1024, height = 1024) {
        return await this.makeRequest('/api/generate-image', {
            method: 'POST',
            body: JSON.stringify({
                prompt,
                style,
                width,
                height
            })
        });
    }

    // Generate voice using Google TTS
    async generateVoice(text, voiceType = 'male', languageCode = 'en-US') {
        return await this.makeRequest('/api/generate-voice', {
            method: 'POST',
            body: JSON.stringify({
                text,
                voice_type: voiceType,
                language_code: languageCode
            })
        });
    }

    // Generate video using FFmpeg with Stable Diffusion images and Google TTS
    async generateVideo(prompt, duration = 5, style = 'cinematic', quality = '1080p', voiceType = 'none', musicStyle = 'none', includeVoiceover = false) {
        return await this.makeRequest('/api/generate-video', {
            method: 'POST',
            body: JSON.stringify({
                prompt,
                duration,
                style,
                quality,
                voice_type: voiceType,
                music_style: musicStyle,
                include_voiceover: includeVoiceover
            })
        });
    }

    // Check video generation status
    async getVideoStatus(videoId) {
        return await this.makeRequest(`/api/video-status/${videoId}`);
    }

    // Process images for video creation
    async processImages(images, effect = 'enhance') {
        return await this.makeRequest('/api/process-images', {
            method: 'POST',
            body: JSON.stringify({
                images,
                effect
            })
        });
    }

    // Merge media into final video
    async mergeMedia(images, audioUrl = '', transitions = 'fade', duration = 10) {
        return await this.makeRequest('/api/merge-media', {
            method: 'POST',
            body: JSON.stringify({
                images,
                audio_url: audioUrl,
                transitions,
                duration
            })
        });
    }

    // Check API health
    async checkHealth() {
        return await this.makeRequest('/api/health');
    }
}

// Video Generator UI Controller
class VideoGenerator {
    constructor() {
        this.api = new AIVideoAPI();
        this.initializeUI();
    }

    initializeUI() {
        // Create form elements
        this.createForm();
        this.bindEvents();
        this.checkAPIHealth();
    }

    createForm() {
        const container = document.getElementById('video-generator') || document.body;
        
        container.innerHTML = `
            <div class="video-generator-container">
                <h2>AI Video Generator</h2>
                
                <div class="api-status" id="api-status">
                    <span>Checking API status...</span>
                </div>

                <form id="video-form" class="video-form">
                    <div class="form-group">
                        <label for="prompt">Video Description:</label>
                        <textarea id="prompt" name="prompt" rows="4" 
                                placeholder="Describe your video... (e.g., A cute cartoon rabbit hopping in a colorful meadow)"
                                required></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="duration">Duration (seconds):</label>
                            <select id="duration" name="duration">
                                <option value="5">5 seconds</option>
                                <option value="10" selected>10 seconds</option>
                                <option value="15">15 seconds</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="style">Style:</label>
                            <select id="style" name="style">
                                <option value="cinematic" selected>Cinematic</option>
                                <option value="realistic">Realistic</option>
                                <option value="artistic">Artistic</option>
                                <option value="animated">Animated</option>
                                <option value="cartoon">Cartoon</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="quality">Quality:</label>
                            <select id="quality" name="quality">
                                <option value="720p">HD (720p)</option>
                                <option value="1080p" selected>Full HD (1080p)</option>
                                <option value="2160p">4K (2160p)</option>
                            </select>
                        </div>
                    </div>

                    <div class="audio-settings">
                        <h3>Audio Settings</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="voice-type">Voice Type:</label>
                                <select id="voice-type" name="voice-type">
                                    <option value="none">No Voice</option>
                                    <option value="male" selected>Male Voice</option>
                                    <option value="female">Female Voice</option>
                                    <option value="child">Child Voice</option>
                                    <option value="robotic">Robotic Voice</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="music-style">Background Music:</label>
                                <select id="music-style" name="music-style">
                                    <option value="none">No Music</option>
                                    <option value="cinematic" selected>Cinematic</option>
                                    <option value="upbeat">Upbeat</option>
                                    <option value="ambient">Ambient</option>
                                    <option value="fantasy">Fantasy</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="include-voiceover" name="include-voiceover" checked>
                                Include AI voiceover narration
                            </label>
                        </div>
                    </div>

                    <button type="submit" id="generate-btn" class="generate-btn">
                        Generate Video
                    </button>
                </form>

                <div id="progress-container" class="progress-container" style="display: none;">
                    <div class="progress-bar">
                        <div id="progress-fill" class="progress-fill"></div>
                    </div>
                    <div id="progress-text" class="progress-text">Processing...</div>
                </div>

                <div id="result-container" class="result-container" style="display: none;">
                    <h3>Generated Video</h3>
                    <div id="video-preview"></div>
                    <div id="download-links"></div>
                </div>
            </div>
        `;
    }

    bindEvents() {
        const form = document.getElementById('video-form');
        form.addEventListener('submit', (e) => this.handleFormSubmit(e));
    }

    async checkAPIHealth() {
        const statusElement = document.getElementById('api-status');
        
        try {
            const health = await this.api.checkHealth();
            
            if (health.status === 'healthy') {
                const services = health.services;
                const warnings = [];
                
                if (!services.stable_diffusion) warnings.push('Stable Diffusion API key missing');
                if (!services.google_tts) warnings.push('Google TTS credentials missing');
                
                if (warnings.length === 0) {
                    statusElement.innerHTML = '<span class="status-good">✓ All services ready</span>';
                } else {
                    statusElement.innerHTML = `<span class="status-warning">⚠ API ready (${warnings.join(', ')})</span>`;
                }
            }
        } catch (error) {
            statusElement.innerHTML = '<span class="status-error">✗ API not available</span>';
        }
    }

    async handleFormSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const data = {
            prompt: formData.get('prompt'),
            duration: parseInt(formData.get('duration')),
            style: formData.get('style'),
            quality: formData.get('quality'),
            voiceType: formData.get('voice-type'),
            musicStyle: formData.get('music-style'),
            includeVoiceover: formData.has('include-voiceover')
        };

        if (!data.prompt.trim()) {
            alert('Please enter a video description');
            return;
        }

        this.showProgress();
        this.disableForm(true);

        try {
            const result = await this.api.generateVideo(
                data.prompt,
                data.duration,
                data.style,
                data.quality,
                data.voiceType,
                data.musicStyle,
                data.includeVoiceover
            );

            if (result.status === 'completed') {
                this.showResult(result);
            } else {
                this.pollVideoStatus(result.video_id);
            }
        } catch (error) {
            this.showError(error.message);
        }
    }

    async pollVideoStatus(videoId) {
        const pollInterval = setInterval(async () => {
            try {
                const status = await this.api.getVideoStatus(videoId);
                
                this.updateProgress(status.progress || 0, status.stage || 'processing');
                
                if (status.status === 'completed') {
                    clearInterval(pollInterval);
                    this.showResult(status);
                } else if (status.status === 'failed') {
                    clearInterval(pollInterval);
                    this.showError('Video generation failed');
                }
            } catch (error) {
                clearInterval(pollInterval);
                this.showError('Failed to check video status');
            }
        }, 2000);
    }

    showProgress() {
        document.getElementById('progress-container').style.display = 'block';
        document.getElementById('result-container').style.display = 'none';
    }

    updateProgress(progress, stage) {
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');
        
        progressFill.style.width = `${progress}%`;
        progressText.textContent = `${stage} (${progress}%)`;
    }

    showResult(result) {
        document.getElementById('progress-container').style.display = 'none';
        document.getElementById('result-container').style.display = 'block';
        
        const videoPreview = document.getElementById('video-preview');
        const downloadLinks = document.getElementById('download-links');
        
        if (result.video_url) {
            videoPreview.innerHTML = `
                <video controls width="100%" max-width="600px">
                    <source src="${result.video_url}" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            `;
            
            downloadLinks.innerHTML = `
                <a href="${result.video_url}" download class="download-btn">Download Video</a>
            `;
        } else {
            videoPreview.innerHTML = '<p>Video generation completed but no preview available.</p>';
        }
        
        this.disableForm(false);
    }

    showError(message) {
        document.getElementById('progress-container').style.display = 'none';
        
        const resultContainer = document.getElementById('result-container');
        resultContainer.style.display = 'block';
        resultContainer.innerHTML = `
            <h3>Error</h3>
            <p class="error-message">${message}</p>
            <p>Please check your API configuration and try again.</p>
        `;
        
        this.disableForm(false);
    }

    disableForm(disabled) {
        const form = document.getElementById('video-form');
        const inputs = form.querySelectorAll('input, select, textarea, button');
        inputs.forEach(input => input.disabled = disabled);
    }
}

// CSS Styles for the UI
const styles = `
    .video-generator-container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        font-family: Arial, sans-serif;
        background: #f5f5f5;
        border-radius: 10px;
    }

    .api-status {
        margin-bottom: 20px;
        padding: 10px;
        border-radius: 5px;
        text-align: center;
    }

    .status-good { color: #28a745; }
    .status-warning { color: #ffc107; }
    .status-error { color: #dc3545; }

    .video-form {
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .form-group {
        margin-bottom: 15px;
    }

    .form-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
    }

    label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    input, select, textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
    }

    textarea {
        resize: vertical;
        min-height: 80px;
    }

    .audio-settings {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 6px;
        margin: 20px 0;
    }

    .audio-settings h3 {
        margin-top: 0;
        color: #495057;
    }

    .generate-btn {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 15px 30px;
        border: none;
        border-radius: 6px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        width: 100%;
        transition: transform 0.2s;
    }

    .generate-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }

    .generate-btn:active {
        transform: translateY(0);
        transition: transform 0.1s;
    }

    .generate-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        transform: none;
    }

    .progress-container {
        margin: 20px 0;
        text-align: center;
    }

    .progress-bar {
        width: 100%;
        height: 20px;
        background: #e9ecef;
        border-radius: 10px;
        overflow: hidden;
        margin-bottom: 10px;
    }

    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #667eea, #764ba2);
        width: 0%;
        transition: width 0.3s ease;
    }

    .result-container {
        background: white;
        padding: 20px;
        border-radius: 8px;
        margin-top: 20px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .download-btn {
        display: inline-block;
        background: #28a745;
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 4px;
        margin-top: 10px;
    }

    .error-message {
        color: #dc3545;
        font-weight: bold;
    }
`;

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Add styles to the page
    const styleSheet = document.createElement('style');
    styleSheet.textContent = styles;
    document.head.appendChild(styleSheet);
    
    // Initialize the video generator
    new VideoGenerator();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AIVideoAPI, VideoGenerator };
}