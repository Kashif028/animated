import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Video } from "@shared/schema";
import { EXAMPLE_PROMPTS, DURATION_OPTIONS, STYLE_OPTIONS, QUALITY_OPTIONS, VOICE_OPTIONS, MUSIC_OPTIONS } from "@/lib/types";
import { Sparkles, Clock, Info, Music, Mic } from "lucide-react";

const videoSchema = z.object({
  prompt: z.string().min(10, "Prompt must be at least 10 characters").max(500, "Prompt must be less than 500 characters"),
  duration: z.number().min(5).max(60),
  style: z.string().min(1, "Please select a style"),
  quality: z.string().min(1, "Please select a quality"),
  voiceType: z.string().optional(),
  musicStyle: z.string().optional(),
  includeVoiceover: z.boolean().optional(),
});

type VideoFormData = z.infer<typeof videoSchema>;

interface VideoGeneratorProps {
  onVideoGenerated: (video: Video | null) => void;
  onGeneratingChange: (isGenerating: boolean) => void;
}

export default function VideoGenerator({ onVideoGenerated, onGeneratingChange }: VideoGeneratorProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<VideoFormData>({
    resolver: zodResolver(videoSchema),
    defaultValues: {
      prompt: "",
      duration: 10,
      style: "animated",
      quality: "1080p",
      voiceType: "none",
      musicStyle: "cinematic",
      includeVoiceover: false,
    },
  });

  const createVideoMutation = useMutation({
    mutationFn: async (data: VideoFormData) => {
      const response = await apiRequest("POST", "/api/videos", data);
      return response.json();
    },
    onSuccess: (video: Video) => {
      setCurrentStep(2);
      onVideoGenerated(video);
      onGeneratingChange(true);
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      
      toast({
        title: "Video generation started!",
        description: "Your video is being created. This may take a moment.",
      });

      // Poll for video completion
      const pollInterval = setInterval(async () => {
        try {
          const response = await apiRequest("GET", `/api/videos/${video.id}`);
          const updatedVideo = await response.json();
          
          if (updatedVideo.status === "completed") {
            clearInterval(pollInterval);
            setCurrentStep(3);
            onVideoGenerated(updatedVideo);
            onGeneratingChange(false);
            queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
            
            toast({
              title: "Video ready!",
              description: "Your AI-generated video is now available for download.",
            });
          } else if (updatedVideo.status === "failed") {
            clearInterval(pollInterval);
            onGeneratingChange(false);
            toast({
              title: "Generation failed",
              description: "There was an error creating your video. Please try again.",
              variant: "destructive",
            });
          }
        } catch (error) {
          console.error("Error polling video status:", error);
        }
      }, 2000);
      
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to start video generation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: VideoFormData) => {
    createVideoMutation.mutate(data);
  };

  const useExamplePrompt = (promptText: string) => {
    form.setValue("prompt", promptText);
  };

  const promptValue = form.watch("prompt");

  return (
    <section id="generator" className="py-16 lg:py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Step Indicator */}
        <div className="mb-12">
          <div className="flex items-center justify-center space-x-4 mb-8">
            {[
              { step: 1, label: "Describe" },
              { step: 2, label: "Generate" },
              { step: 3, label: "Download" }
            ].map(({ step, label }, index) => (
              <div key={step} className="flex items-center">
                <div className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                    currentStep >= step ? "step-active" : "step-inactive"
                  }`}>
                    {step}
                  </div>
                  <span className={`ml-3 font-medium ${
                    currentStep >= step ? "text-gray-900" : "text-gray-500"
                  }`}>
                    {label}
                  </span>
                </div>
                {index < 2 && (
                  <div className={`w-12 h-0.5 ml-4 ${
                    currentStep > step ? "step-line-active" : "step-line-inactive"
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Main Generator Card */}
        <Card className="shadow-xl card-hover fade-in-up">
          <CardContent className="p-8 lg:p-12">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Describe Your Video</h2>
              <p className="text-gray-600 text-lg">Tell us what kind of video you want to create. Be as detailed or simple as you like!</p>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                {/* Text Input Section */}
                <FormField
                  control={form.control}
                  name="prompt"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                        What video would you like to create?
                        <Info className="w-4 h-4 text-gray-500" />
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Textarea
                            {...field}
                            placeholder="Example: A serene sunset over a calm lake with gentle ripples, birds flying across the golden sky, peaceful and cinematic..."
                            className="h-32 text-lg resize-none"
                          />
                          <div className="absolute bottom-4 right-4 text-sm text-gray-400">
                            {promptValue.length}/500 characters
                          </div>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Prompt Examples */}
                <div>
                  <p className="text-sm font-semibold text-gray-700 mb-4">Need inspiration? Try these examples:</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {EXAMPLE_PROMPTS.map((example, index) => (
                      <Button
                        key={index}
                        type="button"
                        variant="outline"
                        className="text-left p-4 h-auto justify-start hover:border-primary/50"
                        onClick={() => useExamplePrompt(example.text)}
                      >
                        <div className="flex flex-col items-start w-full">
                          <div className="text-sm text-primary font-medium mb-2">{example.category}</div>
                          <div className="text-sm text-gray-700">"{example.text}"</div>
                        </div>
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Video Settings */}
                <Card className="bg-gray-50">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Video Settings</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      <FormField
                        control={form.control}
                        name="duration"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Duration</FormLabel>
                            <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value.toString()}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {DURATION_OPTIONS.map((option) => (
                                  <SelectItem key={option.value} value={option.value.toString()}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="style"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Style</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {STYLE_OPTIONS.map((option) => (
                                  <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="quality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Quality</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {QUALITY_OPTIONS.map((option) => (
                                  <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Audio Settings */}
                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                      <Music className="w-5 h-5 text-blue-600" />
                      Audio Settings
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="voiceType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="flex items-center gap-2">
                              <Mic className="w-4 h-4" />
                              Voice Narration
                            </FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select voice type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {VOICE_OPTIONS.map((option) => (
                                  <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="musicStyle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="flex items-center gap-2">
                              <Music className="w-4 h-4" />
                              Background Music
                            </FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select music style" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {MUSIC_OPTIONS.map((option) => (
                                  <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="mt-4 p-4 bg-blue-100 rounded-lg">
                      <p className="text-sm text-blue-800 mb-2 font-medium">AI Audio Features:</p>
                      <ul className="text-sm text-blue-700 space-y-1">
                        <li>• Voice narration will describe your video content</li>
                        <li>• Background music matches your selected style</li>
                        <li>• All audio is automatically synchronized with video</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>

                {/* Generate Button */}
                <div className="text-center">
                  <Button 
                    type="submit"
                    size="lg"
                    disabled={createVideoMutation.isPending}
                    className="gradient-primary hover:gradient-primary-hover text-white px-12 py-4 text-xl font-semibold transform hover:scale-105 transition-all shadow-lg"
                  >
                    <Sparkles className="mr-2 w-5 h-5" />
                    <span>Generate My Video</span>
                    <Sparkles className="ml-2 w-5 h-5" />
                  </Button>
                  <p className="text-sm text-gray-500 mt-4 flex items-center justify-center gap-1">
                    <Clock className="w-4 h-4" />
                    Generation typically takes 30-60 seconds
                  </p>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
