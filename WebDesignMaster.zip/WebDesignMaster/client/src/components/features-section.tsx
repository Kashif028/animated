import { Card, CardContent } from "@/components/ui/card";
import { Zap, Palette, Smartphone, Download, Shield, Headphones } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Generate professional-quality videos in under 60 seconds. No waiting, no complex rendering.",
    color: "bg-blue-100 text-blue-600"
  },
  {
    icon: Palette,
    title: "Multiple Styles",
    description: "Choose from cinematic, realistic, artistic, and more styles to match your vision perfectly.",
    color: "bg-purple-100 text-purple-600"
  },
  {
    icon: Smartphone,
    title: "Mobile Friendly",
    description: "Create videos on any device. Our interface works perfectly on phones, tablets, and desktops.",
    color: "bg-green-100 text-green-600"
  },
  {
    icon: Download,
    title: "Easy Downloads",
    description: "Download your videos in multiple formats and resolutions. Ready for social media or presentations.",
    color: "bg-red-100 text-red-600"
  },
  {
    icon: Shield,
    title: "Secure & Private",
    description: "Your content is safe with us. We respect your privacy and secure your data with enterprise-grade encryption.",
    color: "bg-yellow-100 text-yellow-600"
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    description: "Get help whenever you need it. Our support team is available around the clock to assist you.",
    color: "bg-indigo-100 text-indigo-600"
  }
];

export default function FeaturesSection() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Our AI Video Generator?</h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Powerful features designed to make video creation simple, fast, and accessible to everyone.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <Card key={index} className="shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-8 text-center">
                  <div className={`w-16 h-16 ${feature.color} rounded-xl flex items-center justify-center mx-auto mb-6`}>
                    <IconComponent className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
