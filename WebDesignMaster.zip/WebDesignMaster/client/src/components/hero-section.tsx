import { Button } from "@/components/ui/button";
import { Play, ArrowRight, Volume2, VolumeX } from "lucide-react";
import { useState, useRef } from "react";

interface HeroSectionProps {
  onGetStarted: () => void;
}

export default function HeroSection({ onGetStarted }: HeroSectionProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  return (
    <section className="gradient-hero py-16 lg:py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="mb-8">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Create Amazing Videos with{" "}
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              AI Magic
            </span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Transform your ideas into stunning animated videos with voice narration and music. Just describe what you want, and watch AI bring your vision to life.
          </p>
        </div>
        
        {/* Enhanced Video Demo */}
        <div className="mb-12 relative">
          <video 
            ref={videoRef}
            src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            poster="https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600"
            className="rounded-2xl shadow-2xl w-full max-w-3xl mx-auto"
            loop
            autoPlay
            muted={isMuted}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
          />
          
          {/* Video Controls Overlay */}
          <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                onClick={togglePlay}
                className="bg-black/70 hover:bg-black/80 text-white border-0"
              >
                {isPlaying ? "Pause" : <Play className="w-4 h-4" />}
              </Button>
              <Button
                size="sm"
                onClick={toggleMute}
                className="bg-black/70 hover:bg-black/80 text-white border-0"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>
            </div>
            <div className="bg-black/70 text-white px-3 py-1 rounded-lg text-sm">
              🎵 With AI Audio & Voice
            </div>
          </div>
          
          {/* Play Button Overlay */}
          {!isPlaying && (
            <button 
              onClick={togglePlay}
              className="absolute inset-0 flex items-center justify-center group"
            >
              <div className="w-20 h-20 bg-white/90 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                <Play className="text-primary w-8 h-8 ml-1" />
              </div>
            </button>
          )}
        </div>

        <Button 
          onClick={onGetStarted}
          size="lg"
          className="gradient-primary hover:gradient-primary-hover text-white px-8 py-4 text-lg font-semibold transform hover:scale-105 transition-all shadow-lg"
        >
          <span>Start Creating Now</span>
          <ArrowRight className="ml-2 w-5 h-5" />
        </Button>
      </div>
    </section>
  );
}
