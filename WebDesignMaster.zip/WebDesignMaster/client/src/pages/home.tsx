import { useState } from "react";
import HeroSection from "@/components/hero-section";
import VideoGenerator from "@/components/video-generator";
import ProgressDisplay from "@/components/progress-display";
import VideoHistory from "@/components/video-history";
import FeaturesSection from "@/components/features-section";
import { Video } from "@shared/schema";
import { Play, Video as VideoIcon, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Home() {
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const scrollToGenerator = () => {
    const element = document.getElementById('generator');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const navigation = [
    { name: "Gallery", href: "#history" },
    { name: "Pricing", href: "#" },
    { name: "Help", href: "#" }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                <VideoIcon className="text-white w-4 h-4" />
              </div>
              <span className="text-xl font-semibold text-gray-900">AI Video Creator</span>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-gray-600 hover:text-primary transition-colors"
                >
                  {item.name}
                </a>
              ))}
              <Button className="gradient-primary hover:gradient-primary-hover text-white">
                Sign In
              </Button>
            </nav>

            {/* Mobile Navigation */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col space-y-4 mt-8">
                  {navigation.map((item) => (
                    <a
                      key={item.name}
                      href={item.href}
                      className="text-gray-600 hover:text-primary transition-colors py-2"
                    >
                      {item.name}
                    </a>
                  ))}
                  <Button className="gradient-primary hover:gradient-primary-hover text-white mt-4">
                    Sign In
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <HeroSection onGetStarted={scrollToGenerator} />

      {/* Video Generator */}
      <VideoGenerator 
        onVideoGenerated={setCurrentVideo}
        onGeneratingChange={setIsGenerating}
      />

      {/* Progress and Results */}
      {(isGenerating || currentVideo) && (
        <ProgressDisplay 
          currentVideo={currentVideo}
          isGenerating={isGenerating}
        />
      )}

      {/* Video History */}
      <VideoHistory />

      {/* Features Section */}
      <FeaturesSection />

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                  <VideoIcon className="text-white w-4 h-4" />
                </div>
                <span className="text-xl font-semibold">AI Video Creator</span>
              </div>
              <p className="text-gray-400 mb-6 max-w-md">
                Transform your ideas into stunning videos with the power of artificial intelligence. Create, share, and inspire.
              </p>
              <div className="flex space-x-4">
                {['twitter', 'instagram', 'youtube', 'discord'].map((social) => (
                  <a
                    key={social}
                    href="#"
                    className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors"
                  >
                    <span className="sr-only">{social}</span>
                    <div className="w-5 h-5 bg-gray-400"></div>
                  </a>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Integrations</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Status</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Community</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 AI Video Creator. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Cookies</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
