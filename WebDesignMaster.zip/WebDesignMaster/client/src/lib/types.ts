export interface VideoGenerationRequest {
  prompt: string;
  duration: number;
  style: string;
  quality: string;
  voiceType?: string;
  musicStyle?: string;
  includeVoiceover?: boolean;
}

export interface ExamplePrompt {
  category: string;
  icon: string;
  text: string;
}

export const EXAMPLE_PROMPTS: ExamplePrompt[] = [
  {
    category: "🐰 Cartoon Animals",
    icon: "🐰",
    text: "Cute cartoon rabbit hopping through a colorful meadow with butterflies"
  },
  {
    category: "🏰 Fantasy World", 
    icon: "🏰",
    text: "Magical castle floating in clouds with animated sparkles and flying dragons"
  },
  {
    category: "🚀 Space Adventure",
    icon: "🚀", 
    text: "Cartoon astronaut exploring colorful alien planet with bouncing movements"
  },
  {
    category: "🌈 Dreamscape",
    icon: "🌈",
    text: "Animated rainbow forest with dancing trees and floating musical notes"
  }
];

export const DURATION_OPTIONS = [
  { value: 5, label: "5 seconds" },
  { value: 10, label: "10 seconds" },
  { value: 15, label: "15 seconds" }
];

export const STYLE_OPTIONS = [
  { value: "cinematic", label: "Cinematic" },
  { value: "realistic", label: "Realistic" },
  { value: "artistic", label: "Artistic" },
  { value: "animated", label: "Animated" }
];

export const QUALITY_OPTIONS = [
  { value: "720p", label: "HD (720p)" },
  { value: "1080p", label: "Full HD (1080p)" },
  { value: "2160p", label: "4K (2160p)" }
];

export const VOICE_OPTIONS = [
  { value: "none", label: "No Voice" },
  { value: "male", label: "Male Voice" },
  { value: "female", label: "Female Voice" },
  { value: "child", label: "Child Voice" },
  { value: "robotic", label: "Robotic Voice" }
];

export const MUSIC_OPTIONS = [
  { value: "none", label: "No Music" },
  { value: "cinematic", label: "Cinematic" },
  { value: "upbeat", label: "Upbeat" },
  { value: "ambient", label: "Ambient" },
  { value: "fantasy", label: "Fantasy" },
  { value: "electronic", label: "Electronic" }
];
