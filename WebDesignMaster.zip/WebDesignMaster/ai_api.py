from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests
import os
import time
import base64
from PIL import Image
import io
import subprocess
import json
from google.cloud import texttospeech
import tempfile
import uuid

app = Flask(__name__)
CORS(app)

# Configuration
STABLE_DIFFUSION_API_URL = os.getenv('STABLE_DIFFUSION_API_URL', 'https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image')
STABILITY_API_KEY = os.getenv('STABILITY_API_KEY')
GOOGLE_APPLICATION_CREDENTIALS = os.getenv('GOOGLE_APPLICATION_CREDENTIALS')

# Initialize Google TTS client
tts_client = None
if GOOGLE_APPLICATION_CREDENTIALS:
    try:
        tts_client = texttospeech.TextToSpeechClient()
    except Exception as e:
        print(f"Google TTS initialization failed: {e}")

@app.route('/api/generate-image', methods=['POST'])
def generate_image():
    """Generate image using Stable Diffusion"""
    try:
        data = request.json
        prompt = data.get('prompt', '')
        style = data.get('style', 'realistic')
        width = int(data.get('width', 1024))
        height = int(data.get('height', 1024))
        
        if not prompt:
            return jsonify({'error': 'Prompt is required'}), 400
            
        if not STABILITY_API_KEY:
            return jsonify({'error': 'Stability API key not configured. Please provide STABILITY_API_KEY.'}), 500
        
        # Prepare Stable Diffusion request
        headers = {
            'Authorization': f'Bearer {STABILITY_API_KEY}',
            'Content-Type': 'application/json',
        }
        
        # Enhanced prompts for animated style
        if style == "animated":
            prompt_text = f"{prompt}, animated style, cartoon animation, vibrant colors, smooth motion, 2D animation style, high quality"
        elif style == "cartoon":
            prompt_text = f"{prompt}, cartoon style, colorful, playful, character design, high quality"
        else:
            prompt_text = f"{prompt}, {style} style, high quality, detailed"
        
        payload = {
            'text_prompts': [
                {
                    'text': prompt_text,
                    'weight': 1
                }
            ],
            'cfg_scale': 7,
            'height': height,
            'width': width,
            'samples': 1,
            'steps': 50,
        }
        
        # Make request to Stable Diffusion API
        response = requests.post(STABLE_DIFFUSION_API_URL, headers=headers, json=payload)
        
        if response.status_code != 200:
            return jsonify({'error': f'Stable Diffusion API error: {response.status_code}'}), 500
        
        result = response.json()
        image_base64 = result['artifacts'][0]['base64']
        
        # Save image temporarily and return URL
        image_id = str(uuid.uuid4())
        image_filename = f'generated_image_{image_id}.png'
        
        # Decode and save image
        image_data = base64.b64decode(image_base64)
        with open(f'static/{image_filename}', 'wb') as f:
            f.write(image_data)
        
        image_url = f'/static/{image_filename}'
        
        return jsonify({
            'success': True,
            'image_url': image_url,
            'image_base64': image_base64,
            'prompt': prompt,
            'style': style,
            'dimensions': f'{width}x{height}'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/generate-voice', methods=['POST'])
def generate_voice():
    """Generate voice/speech using Google TTS"""
    try:
        data = request.json
        text = data.get('text', '')
        voice_type = data.get('voice_type', 'male')
        language_code = data.get('language_code', 'en-US')
        
        if not text:
            return jsonify({'error': 'Text is required'}), 400
            
        if not tts_client:
            return jsonify({'error': 'Google TTS not configured. Please provide GOOGLE_APPLICATION_CREDENTIALS.'}), 500
        
        # Configure voice based on type
        voice_name_map = {
            'male': 'en-US-Standard-B',
            'female': 'en-US-Standard-C',
            'child': 'en-US-Standard-F',
            'robotic': 'en-US-Standard-A'
        }
        
        voice_name = voice_name_map.get(voice_type, 'en-US-Standard-B')
        
        # Set up the text input to be synthesized
        synthesis_input = texttospeech.SynthesisInput(text=text)
        
        # Build the voice request
        voice = texttospeech.VoiceSelectionParams(
            language_code=language_code,
            name=voice_name,
            ssml_gender=texttospeech.SsmlVoiceGender.MALE if voice_type == 'male' else texttospeech.SsmlVoiceGender.FEMALE
        )
        
        # Select the audio format
        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MP3
        )
        
        # Perform the text-to-speech request
        response = tts_client.synthesize_speech(
            input=synthesis_input,
            voice=voice,
            audio_config=audio_config
        )
        
        # Save audio file temporarily
        audio_id = str(uuid.uuid4())
        audio_filename = f'generated_audio_{audio_id}.mp3'
        
        with open(f'static/{audio_filename}', 'wb') as f:
            f.write(response.audio_content)
        
        # Convert audio to base64 for transmission
        audio_base64 = base64.b64encode(response.audio_content).decode('utf-8')
        
        return jsonify({
            'success': True,
            'audio_url': f'/static/{audio_filename}',
            'audio_base64': audio_base64,
            'text': text,
            'voice_type': voice_type,
            'language_code': language_code,
            'format': 'mp3'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/generate-video', methods=['POST'])
def generate_video():
    """Generate video using FFmpeg with images and audio"""
    try:
        data = request.json
        prompt = data.get('prompt', '')
        duration = data.get('duration', 5)
        style = data.get('style', 'cinematic')
        quality = data.get('quality', '1080p')
        voice_type = data.get('voice_type', 'none')
        music_style = data.get('music_style', 'none')
        include_voiceover = data.get('include_voiceover', False)
        
        if not prompt:
            return jsonify({'error': 'Prompt is required'}), 400
        
        video_id = str(uuid.uuid4())
        
        # Step 1: Generate images using Stable Diffusion
        if style == "animated":
            image_prompts = [
                f"{prompt}, animated style, cartoon animation, vibrant colors, frame 1, 2D animation",
                f"{prompt}, animated style, cartoon animation, vibrant colors, frame 2, 2D animation", 
                f"{prompt}, animated style, cartoon animation, vibrant colors, frame 3, 2D animation",
                f"{prompt}, animated style, cartoon animation, vibrant colors, frame 4, 2D animation"
            ]
        elif style == "cartoon":
            image_prompts = [
                f"{prompt}, cartoon style, colorful, playful, frame 1",
                f"{prompt}, cartoon style, colorful, playful, frame 2", 
                f"{prompt}, cartoon style, colorful, playful, frame 3",
                f"{prompt}, cartoon style, colorful, playful, frame 4"
            ]
        else:
            image_prompts = [
                f"{prompt}, {style} style, frame 1",
                f"{prompt}, {style} style, frame 2", 
                f"{prompt}, {style} style, frame 3",
                f"{prompt}, {style} style, frame 4"
            ]
        
        image_files = []
        for i, img_prompt in enumerate(image_prompts):
            if STABILITY_API_KEY:
                # Generate image with Stable Diffusion
                headers = {
                    'Authorization': f'Bearer {STABILITY_API_KEY}',
                    'Content-Type': 'application/json',
                }
                
                payload = {
                    'text_prompts': [{'text': img_prompt, 'weight': 1}],
                    'cfg_scale': 7,
                    'height': 1024,
                    'width': 1024,
                    'samples': 1,
                    'steps': 30,
                }
                
                response = requests.post(STABLE_DIFFUSION_API_URL, headers=headers, json=payload)
                if response.status_code == 200:
                    result = response.json()
                    image_data = base64.b64decode(result['artifacts'][0]['base64'])
                    image_filename = f'frame_{video_id}_{i}.png'
                    image_path = f'static/{image_filename}'
                    
                    with open(image_path, 'wb') as f:
                        f.write(image_data)
                    image_files.append(image_path)
        
        # Step 2: Generate voiceover using Google TTS
        audio_path = None
        if include_voiceover and voice_type != 'none' and tts_client:
            voice_name_map = {
                'male': 'en-US-Standard-B',
                'female': 'en-US-Standard-C',
                'child': 'en-US-Standard-F',
                'robotic': 'en-US-Standard-A'
            }
            
            voice_name = voice_name_map.get(voice_type, 'en-US-Standard-B')
            
            synthesis_input = texttospeech.SynthesisInput(text=prompt)
            voice = texttospeech.VoiceSelectionParams(
                language_code='en-US',
                name=voice_name,
                ssml_gender=texttospeech.SsmlVoiceGender.MALE if voice_type == 'male' else texttospeech.SsmlVoiceGender.FEMALE
            )
            audio_config = texttospeech.AudioConfig(
                audio_encoding=texttospeech.AudioEncoding.MP3
            )
            
            tts_response = tts_client.synthesize_speech(
                input=synthesis_input,
                voice=voice,
                audio_config=audio_config
            )
            
            audio_filename = f'voiceover_{video_id}.mp3'
            audio_path = f'static/{audio_filename}'
            
            with open(audio_path, 'wb') as f:
                f.write(tts_response.audio_content)
        
        # Step 3: Create video using FFmpeg
        if image_files:
            video_filename = f'video_{video_id}.mp4'
            video_path = f'static/{video_filename}'
            
            # Create video from images
            frame_duration = duration / len(image_files)
            
            # FFmpeg command to create video from images
            ffmpeg_cmd = [
                'ffmpeg', '-y',
                '-framerate', f'{1/frame_duration}',
                '-pattern_type', 'glob',
                '-i', f'static/frame_{video_id}_*.png',
                '-c:v', 'libx264',
                '-pix_fmt', 'yuv420p',
                '-t', str(duration)
            ]
            
            # Add audio if available
            if audio_path:
                ffmpeg_cmd.extend(['-i', audio_path, '-c:a', 'aac', '-shortest'])
            
            ffmpeg_cmd.append(video_path)
            
            # Execute FFmpeg command
            result = subprocess.run(ffmpeg_cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                return jsonify({
                    'success': True,
                    'video_id': video_id,
                    'status': 'completed',
                    'video_url': f'/static/{video_filename}',
                    'thumbnail_url': f'/static/frame_{video_id}_0.png' if image_files else None,
                    'settings': {
                        'prompt': prompt,
                        'duration': duration,
                        'style': style,
                        'quality': quality,
                        'voice_type': voice_type,
                        'music_style': music_style,
                        'include_voiceover': include_voiceover
                    }
                })
            else:
                return jsonify({'error': f'FFmpeg error: {result.stderr}'}), 500
        
        return jsonify({
            'success': True,
            'video_id': video_id,
            'status': 'processing',
            'message': 'Video generation started (requires API keys for full functionality)',
            'estimated_time': duration * 10,
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/video-status/<int:video_id>', methods=['GET'])
def get_video_status(video_id):
    """Check video generation status"""
    try:
        # Simulate processing stages
        import random
        progress = random.randint(0, 100)
        
        if progress < 100:
            status = 'processing'
            stage = 'generating_frames' if progress < 60 else 'adding_audio'
        else:
            status = 'completed'
            stage = 'finished'
        
        return jsonify({
            'video_id': video_id,
            'status': status,
            'progress': progress,
            'stage': stage,
            'video_url': f'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' if status == 'completed' else None,
            'thumbnail_url': 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400' if status == 'completed' else None
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/process-images', methods=['POST'])
def process_images():
    """Process and enhance images for video creation"""
    try:
        data = request.json
        images = data.get('images', [])
        effect = data.get('effect', 'enhance')
        
        if not images:
            return jsonify({'error': 'Images are required'}), 400
        
        # Simulate image processing
        processed_images = []
        for img_url in images:
            processed_images.append({
                'original_url': img_url,
                'processed_url': img_url,  # In real implementation, return processed image URL
                'effect_applied': effect
            })
        
        return jsonify({
            'success': True,
            'processed_images': processed_images,
            'effect': effect,
            'processing_time': len(images) * 0.5
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/merge-media', methods=['POST'])
def merge_media():
    """Merge images, audio, and effects into final video"""
    try:
        data = request.json
        images = data.get('images', [])
        audio_url = data.get('audio_url', '')
        transitions = data.get('transitions', 'fade')
        duration = data.get('duration', 10)
        
        if not images:
            return jsonify({'error': 'Images are required for video creation'}), 400
        
        # Simulate video merging process
        merge_id = int(time.time())
        
        return jsonify({
            'success': True,
            'merge_id': merge_id,
            'status': 'merging',
            'estimated_completion': duration + 30,  # Base time + processing overhead
            'settings': {
                'images_count': len(images),
                'has_audio': bool(audio_url),
                'transitions': transitions,
                'duration': duration
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """API health check"""
    return jsonify({
        'status': 'healthy',
        'services': {
            'stable_diffusion': bool(STABILITY_API_KEY),
            'google_tts': bool(tts_client),
            'ffmpeg': True,
            'image_generation': bool(STABILITY_API_KEY),
            'voice_synthesis': bool(tts_client),
            'video_processing': True
        },
        'timestamp': time.time(),
        'required_env_vars': {
            'STABILITY_API_KEY': bool(STABILITY_API_KEY),
            'GOOGLE_APPLICATION_CREDENTIALS': bool(GOOGLE_APPLICATION_CREDENTIALS)
        }
    })

# Serve static files
@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

@app.route('/')
def serve_index():
    return send_from_directory('.', 'index.html')

# Create static directory if it doesn't exist
import os
if not os.path.exists('static'):
    os.makedirs('static')

if __name__ == '__main__':
    print("Starting AI Video Generator API...")
    print(f"Stability API configured: {bool(STABILITY_API_KEY)}")
    print(f"Google TTS configured: {bool(tts_client)}")
    app.run(host='0.0.0.0', port=8000, debug=True)